package p1;

import java.io.*;
import java.util.*;
import java.util.Map.Entry;



public class Excel {
	public static void Field(ArrayList<String> al, String path2) throws Exception
	{
		// TODO Auto-generated method stub
		
		String field="field";
		String x = null;
		String y = null;
		HashMap hm=new HashMap();
		HashMap hm1=new HashMap();
		for(int i=0;i<8;i++)
		{
			FileReader f2=new FileReader(path2);
			
			BufferedReader br2= new BufferedReader(f2);
			Scanner scanid = new Scanner(br2);

			int count=0,count1=0;
		while(scanid.hasNextLine())
		{
			
			String data= scanid.nextLine();
			
			
		
			String[] value = data.split(",");
			
			x="";
			y="";
			if("2016".equals(value[1]))
			{
			
				 x=value[6];
				 y=value[7];
			
				if(x.equals(al.get(i)) && y.equals(field))
				{
					count++;
				}
				//System.out.println(" *"+x+" *"+y+" *");
			
			}
			else if("2017".equals(value[1]))
			{
				
				 x=value[6];
				 y=value[7];
			
				if(x.equals(al.get(i)) && y.equals(field))
				{
					count1++;
				}
				//System.out.println(" *"+x+" *"+y+" *");
			
			}
		}
	//System.out.println(al.get(i));
		if(count>6)
		{
			hm.put(al.get(i), count);
		}
		if(count1>5)
		{
			hm1.put(al.get(i), count1);
		}
		//hm.putIfAbsent(count, al.get(i));
		
	br2.close();
	f2.close();
		}
		

		 TreeMap<String,Integer> sorted = new TreeMap<>();
		 TreeMap<String,Integer> sorted1 = new TreeMap<>();
	        // Copy all data from hashMap into TreeMap
	        sorted.putAll(hm);
	 sorted.descendingMap();
	 sorted1.putAll(hm1);
	 sorted1.descendingMap();
	 
	        // Display the TreeMap which is naturally sorted
	 		System.out.println("Year	Count		Team");
	        for (Entry<String,Integer> entry : sorted.entrySet()) 
	        {	
	            System.out.println("2016	 " + entry.getValue() + 
	                         "	  " + entry.getKey());
	        }
	        for (Entry<String,Integer> entry : sorted1.entrySet()) 
	        {	
	            System.out.println("2017	 " + entry.getValue() + 
	                         "	  " + entry.getKey());
	        }
	}
	
	public static void Totalruns(ArrayList<String> al, String path1) throws Exception 
	{
		// TODO Auto-generated method stub
		HashMap hm=new HashMap();
		HashMap hm1=new HashMap();
		HashMap hm2=new HashMap();
		for(int i=0;i<10;i++)
		{
			FileReader f1=new FileReader(path1);
			String x="";
			String y="";
			BufferedReader br1= new BufferedReader(f1);
			Scanner scanid = new Scanner(br1);
			long sum= 0;
			int four=0,six=0;
			while(scanid.hasNextLine())
			{
				
				String data= scanid.nextLine();
				String[] value = data.split(",");
				
				
				
				x=value[13];
				y=value[0];
				//if("2017".equals(w) && y.equals(z))
				//{
				
					if(al.get(i).equals(value[2]))
					{
						//sum=+x[1];
						if("4".equals(x))
						{
							four++;
							sum+=4;
						}
						else if("6".equals(x))
						{
							six++;
							sum+=6;
						}
						else if("1".equals(x))
						{
							sum+=1;
						}
						else if("2".equals(x))
						{
							sum+=2;
						}
						else if("3".equals(x))
						{
							sum+=3;
						}
						else if("5".equals(x))
						{
							sum+=5;
						}
						else if("7".equals(x))
						{
							sum+=7;
						}
					}
				//}
					//System.out.println(x);
			}
			hm.put(al.get(i), four);
			hm1.put(al.get(i), six);
			hm2.put(al.get(i), sum);
			//System.out.println(x);
			br1.close();
			f1.close();
			//br2.close();
			//f2.close();
			
		}
		
		//System.out.println(hm);
		//System.out.println(hm1);
		TreeMap<String,Integer> sorted = new TreeMap<>();
	    TreeMap<String,Integer> sorted1 = new TreeMap<>();
	    sorted.putAll(hm);
	    sorted.descendingMap();
	    sorted1.putAll(hm1);
	    sorted1.descendingMap();
	    TreeMap<String,Long> sorted2 = new TreeMap<>();
	    sorted2.putAll(hm2);
	    sorted2.descendingMap();
	    
	    System.out.println("Fours		Teams");
		 for (Entry<String,Integer> entry : sorted.entrySet()) 
	        {	
	            System.out.println( entry.getValue() + 
	                         "	  " + entry.getKey());
	        }
		 System.out.println();System.out.println("********************************");
			System.out.println();
		 System.out.println("Six		Teams");
	        for (Entry<String,Integer> entry : sorted1.entrySet()) 
	        {	
	            System.out.println( entry.getValue() + 
	                         "	  " + entry.getKey());
	        }
	        System.out.println();System.out.println("********************************");
			System.out.println();
	        System.out.println("Total Score		Teams");
			 for (Entry<String, Long> entry : sorted2.entrySet()) 
		        {	
		            System.out.println( "  "+entry.getValue() + 
		                         "   	 " + entry.getKey());
		        }
			
	}
	public static void main(String[] args) throws Exception    
	{
		// TODO Auto-generated method stub
		
		String path1="E:\\ipl//deliveries.csv";
		String path2="E:\\ipl//matches.csv";
		ArrayList<String> al=new ArrayList<String>();		
		al.add("Sunrisers Hyderabad");
		al.add("Royal Challengers Bangalore");
		al.add("Rising Pune Supergiant");
		al.add("Mumbai Indians");
		al.add("Gujarat Lions");
		al.add("Kolkata Knight Riders");
		al.add("Kings XI Punjab");
		al.add("Delhi Daredevils");
		al.add("Chennai Super Kings");
		al.add("Rajasthan Royals");
		
		
		
		
		
		Field(al,path2);
		System.out.println();System.out.println("********************************");
		System.out.println();
		Totalruns(al,path1);
		
	}

	

	

	
	

}
